package com.example.airgaplockdownapp

import android.content.Intent
import android.graphics.Point
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient
import java.nio.charset.StandardCharsets
import java.util.*

class MainActivity : AppCompatActivity() {

    // HiveMQ client
    private lateinit var mqttClient: Mqtt5AsyncClient
    private val serverUri = "4938f87b6b6745b097662d232690deb4.s1.eu.hivemq.cloud"
    private val serverPort = 8883
    private val clientId = UUID.randomUUID().toString()
    private val publishTopic = "test/topic"
    private val username = "tester"
    private val passwordString = "Password1"
    private var reconnectHandler: Handler = Handler(Looper.getMainLooper())
    private val reconnectInterval: Long = 5000

    // Track lock/unlock state
    private var isLocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize HiveMQ MQTT client
        mqttClient = MqttClient.builder()
            .identifier(clientId)
            .serverHost(serverUri)
            .serverPort(serverPort)
            .sslWithDefaultConfig()
            .useMqttVersion5()
            .buildAsync()

        // Connect to MQTT broker
        connectMQTT()

        // Get references to the lock/unlock image and background
        val lockUnlockImage = findViewById<ImageView>(R.id.lockUnlockImage)
        val backgroundImage = findViewById<ImageView>(R.id.backgroundImage)

        // Dynamically update button size based on screen size
        setDynamicButtonSize(lockUnlockImage)

        // Handle image click for lock/unlock
        lockUnlockImage.setOnClickListener {
            if (isLocked) {
                unlockDevice(lockUnlockImage, backgroundImage)
            } else {
                lockDevice(lockUnlockImage, backgroundImage)
            }
            isLocked = !isLocked
        }
    }

    // Connect to HiveMQ Cloud using TLS and username/password
    private fun connectMQTT() {
        mqttClient.connectWith()
            .simpleAuth()
            .username(username)
            .password(passwordString.toByteArray(StandardCharsets.UTF_8))
            .applySimpleAuth()
            .send()
            .whenComplete { _, throwable ->
                runOnUiThread {
                    if (throwable != null) {
                        // Connection failed, try again after 5 seconds
                        Toast.makeText(this, "MQTT Connection Failed: ${throwable.message}. Retrying...", Toast.LENGTH_LONG).show()
                        scheduleReconnect()
                    } else {
                        // Connection succeeded
                        Toast.makeText(this, "MQTT Connected", Toast.LENGTH_SHORT).show()
                    }
                }
            }
    }

    // Schedule reconnection attempt after 5 seconds
    private fun scheduleReconnect() {
        reconnectHandler.postDelayed({
            connectMQTT()
        }, reconnectInterval)
    }

    // Dynamically calculate and set the size of the lock/unlock button based on screen size
    private fun setDynamicButtonSize(lockUnlockImage: ImageView) {
        val display = windowManager.defaultDisplay
        val size = Point()
        display.getSize(size)
        val screenWidth = size.x
        val screenHeight = size.y

        val buttonWidth = (screenWidth * 0.4).toInt()  // 40% of screen width
        val buttonHeight = (screenHeight * 0.2).toInt()  // 20% of screen height

        val layoutParams = lockUnlockImage.layoutParams
        layoutParams.width = buttonWidth
        layoutParams.height = buttonHeight
        lockUnlockImage.layoutParams = layoutParams
    }

    // Publish a message to the MQTT broker
    private fun publishMessage(message: String) {
        if (mqttClient.state.isConnected) {
            mqttClient.publishWith()
                .topic(publishTopic)
                .payload(message.toByteArray(StandardCharsets.UTF_8))
                .send()
                .whenComplete { _, throwable ->
                    runOnUiThread {
                        if (throwable != null) {
                            Toast.makeText(this, "Publish failed: ${throwable.message}", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Message published", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
        } else {
            Toast.makeText(this, "MQTT Client is not connected", Toast.LENGTH_SHORT).show()
        }
    }

    // Lock the device
    private fun lockDevice(lockUnlockImage: ImageView, backgroundImage: ImageView) {
        if (mqttClient.state.isConnected) {
            publishMessage("lock")
            showAirplaneModeDialog("Enable Airplane Mode", "Please enable Airplane Mode to lock the device.")

            // Change background and button to "locked" state
            backgroundImage.setImageResource(R.drawable.locked_background)
            lockUnlockImage.setImageResource(R.drawable.locked_button)

            Toast.makeText(this, "Device locked", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "MQTT not connected", Toast.LENGTH_SHORT).show()
        }
    }

    // Unlock the device
    private fun unlockDevice(lockUnlockImage: ImageView, backgroundImage: ImageView) {
        showAirplaneModeDialog("Disable Airplane Mode", "Please disable Airplane Mode to unlock the device.")
        // Change background and button to "unlocked" state
        backgroundImage.setImageResource(R.drawable.unlocked_background)
        lockUnlockImage.setImageResource(R.drawable.unlocked_button)

        // Start checking if Airplane mode is disabled
        reconnectHandler.postDelayed({
            if (!isAirplaneModeEnabled()) {
                connectMQTT()  // Attempt to reconnect MQTT after airplane mode is disabled

                // Check for successful MQTT connection after 5 seconds
                reconnectHandler.postDelayed({
                    if (mqttClient.state.isConnected) {
                        publishMessage("unlock")
                        Toast.makeText(this, "Device unlocked", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Failed to reconnect MQTT", Toast.LENGTH_SHORT).show()
                    }
                }, 5000)
            } else {
                Toast.makeText(this, "Airplane mode still enabled", Toast.LENGTH_SHORT).show()
            }
        }, 5000)
    }

    // Show a dialog to instruct the user to enable/disable airplane mode
    private fun showAirplaneModeDialog(title: String, message: String) {
        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK") { dialogInterface, _ ->
                openAirplaneModeSettings()
                dialogInterface.dismiss()
            }
            .create()
        dialog.show()
    }

    // Enable Airplane Mode
    private fun openAirplaneModeSettings() {
        val intent = Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
        startActivity(intent)
    }

    // Check if airplane mode is enabled
    private fun isAirplaneModeEnabled(): Boolean {
        return Settings.Global.getInt(
            contentResolver,
            Settings.Global.AIRPLANE_MODE_ON, 0
        ) != 0
    }

    override fun onDestroy() {
        super.onDestroy()
        // Safely disconnect the MQTT client when the app is closed
        mqttClient.disconnect()
        // Remove any scheduled reconnect attempts
        reconnectHandler.removeCallbacksAndMessages(null)
    }
}
